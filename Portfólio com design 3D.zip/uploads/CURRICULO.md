# Ryan Nishikawa

**Engenheiro de IA · Desenvolvedor Full-Stack · Desenvolvedor RPA · Engenheiro de Automação**

> Sistemas que leem, raciocinam e agem.

| | |
|---|---|
| **Localização** | Campinas, BR |
| **Disponibilidade** | Aberto a oportunidades remotas |
| **Email** | ryan.nishikawa@hotmail.com |
| **LinkedIn** | [in/ryan-nishikawa](https://www.linkedin.com/in/ryan-nishikawa) |
| **GitHub** | [github.com/Nishuw](https://github.com/Nishuw) |
| **Site** | [www.nishikawa.app](https://www.nishikawa.app/) |

---

## Resumo profissional

**De cabos de rede a redes neurais.**

Construo sistemas de IA que leem, raciocinam e agem — pipelines de RAG, agentes autônomos e automação que elimina trabalho repetitivo, de ponta a ponta, em produção.

Comecei em infraestrutura de redes corporativas, migrei para engenharia backend e RPA e hoje projeto sistemas de IA — pipelines de RAG, agentes de LLM e automação que roda sem supervisão em produção. Esse caminho — do cabo ao modelo — é o motivo de meus sistemas sobreviverem ao mundo real: penso em modos de falha, observabilidade e escala antes da primeira linha de código.

**Trilha:** Redes → Automação & RPA → Engenharia de IA

### Números

- **3+** anos entregando software e automação
- **13** repositórios públicos no GitHub
- **2** hackathons internacionais — RAISE Summit e Google Cloud
- **98%** de taxa de sucesso em RPAs de produção

---

## Experiência profissional

### Analista de Sistemas RPA — Mix Fiscal
**Campinas, BR · FEV 2026 — ATUAL**

- Projeto e orquestro **sistemas de RPA para classificação fiscal** processando centenas de registros por execução com **98% de precisão** — eliminando totalmente a revisão manual.
- Desenhei a **camada de observabilidade**: cada execução é rastreável de ponta a ponta por logs estruturados e relatórios automáticos.
- Dono de toda a stack da plataforma de automação — bots em Python, persistência em PostgreSQL, integrações REST — dentro de um time Scrum.

`Python` · `RPA` · `PostgreSQL` · `REST APIs` · `Scrum`

### Analista de Desenvolvimento — Global Hitss
**Campinas, BR · ABR 2025 — FEV 2026**

- Construí **4 ferramentas internas de automação** para operações de banco de dados e geração de relatórios — removendo horas de trabalho repetitivo por semana no time.
- Desenvolvi um **sistema de análise de logs para infraestrutura Cisco/Nokia** que interpreta interfaces, QoS, rotas e protocolos — reduzindo o tempo de diagnóstico de rede em campo.
- Entreguei um **chatbot técnico no Telegram** (orquestrado com n8n) com base de conhecimento Cisco/FortiGate/Huawei para engenheiros de campo.
- Desenvolvi um **portal de conhecimento** interno com ingestão de PDF, DOC, CSV e JSON e busca com OCR.

`Python` · `n8n` · `OCR` · `Chatbots` · `MySQL`

### Técnico em Automação de Redes — Global Hitss
**Campinas, BR · AGO 2024 — JUL 2025**

- Suporte e resolução de incidentes em redes corporativas — a **base de infraestrutura** que hoje informa como projeto automações resilientes e conscientes do ambiente.

`Redes` · `Linux` · `Infraestrutura`

---

## Conquistas e hackathons

*Construído sob pressão. Provado em competição: dois hackathons internacionais, dois produtos de IA entregues.*

### RAISE Summit Hackathon — Paris, 4–5 JUL 2026
**DocRAG BR — o RAG que se audita** · Build solo em 48h

Todos construíram "chat com PDF". Eu inverti o fluxo: um **auditor autônomo** para documentos financeiros brasileiros que fala primeiro — cruzando o que a narrativa afirma com o que as tabelas e gráficos realmente mostram.

- Sinaliza as próprias alucinações em tempo real — cada número é verificado contra a fonte
- Grounding no nível do pixel: cada citação abre a página real do PDF, destacada
- Lê gráficos vetoriais invisíveis a pipelines comuns via renderização com Vision LLM
- Recuperação em dois estágios: roteamento de intenção por LLM + reranking sobre ChromaDB

Repositório: https://github.com/Nishuw/DocRAG-BR

### Google Cloud / GKE Hackathon — SET 2025 (GKE 10 anos)
**Agente de IA para Online Boutique** · Microsserviço de IA

Um **microsserviço de agente de IA** plugado ao Online Boutique do Google: analisa comportamento do usuário e tendências de mercado para gerar ofertas personalizadas — começando pela recuperação de carrinhos abandonados.

- Geração de ofertas com Gemini e contratos validados por Pydantic
- Serviço FastAPI desenhado para Kubernetes — pronto para GKE desde o dia um
- Totalmente conteinerizado: Docker + Compose local, manifests K8s para nuvem
- Health checks, logging estruturado e modelos tipados de ponta a ponta

Repositório: https://github.com/Nishuw/online-boutique-ai-agent

**Marcadores dos builds:** 48h de build solo do zero · 0 alucinações (tudo auditado) · 2 palcos internacionais · 100% pronto para produção

---

## Competências técnicas

| Domínio | Tecnologias |
|---|---|
| **IA & LLMs** | LLMs · RAG · Agentes de IA · Sistemas Multiagente · Engenharia de Prompt · LangChain · MCP · Bancos Vetoriais |
| **Automação** | RPA · Web Scraping · OCR · n8n · Automação de Processos |
| **Linguagens** | Python (principal) · TypeScript · JavaScript · SQL |
| **Web & Backend** | React · Node.js · FastAPI · Flask · REST APIs |
| **Dados & Infra** | Docker · Cloud (GCP · Kubernetes) · PostgreSQL · MySQL · Linux · Git |

---

## Projetos

### DocRAG BR — destaque (RAISE Summit '26)
O analista autônomo que audita documentos financeiros — e prova cada afirmação até o pixel. Ingestão multiformato (texto, tabelas, gráficos vetoriais), recuperação em dois estágios e uma camada de verificação pós-resposta que captura as próprias alucinações do LLM antes do usuário ver.

Pipeline: ingestão de 3 formatos (texto · tabelas · gráficos vetoriais) → embed e índice local multilíngue no ChromaDB → roteamento de intenção e rerank de chunks (2 estágios) → auditoria de cada número contra a fonte (0 alucinações).

`Python` · `RAG` · `ChromaDB` · `Sentence-Transformers` · `Vision LLM` · `OpenRouter`
https://github.com/Nishuw/DocRAG-BR

### Projeto Petrova — destaque (pesquisa)
Pesquisa empírica sobre algoritmos de chunking para RAG em tabelas financeiras. Tese: reformular cada linha da tabela em um chunk autossuficiente — carregando título, unidade e cabeçalhos — elimina o colapso de precisão do chunking genérico. Medido em documentos reais da CVM/B3, avaliado por Llama-3.3-70b: até **+85,7pp de acurácia por apenas +15–26% de tokens**.

Resultados: Vale 1T26 (tabela de produção) 0% → 85,7% · Itaú 4T25 (demonstração de resultados) 0% → 71,4% · Itaú 4T25 (linhas ruidosas) 14,3% → 100%.

`Pesquisa RAG` · `Chunking` · `LLM-as-Judge` · `NLP` · `Python`
https://github.com/Nishuw/Projeto-Petrova

### Online Boutique AI Agent
Build do hackathon do Google Cloud — microsserviço de agente de IA que recupera carrinhos abandonados com ofertas personalizadas geradas por Gemini. FastAPI, Docker, pronto para GKE.

`Gemini` · `FastAPI` · `Kubernetes`
https://github.com/Nishuw/online-boutique-ai-agent

### NetRouter AI
Copiloto de IA para engenheiros de rede — diagnostica problemas e gera scripts de configuração para Cisco, Nokia, FortiGate e Huawei, com Gemini e um dashboard estilo NOC.

`Gemini` · `Flask` · `Chart.js`
https://github.com/Nishuw/NetrouterAI

### WaSender Pro
Plataforma de automação de campanhas no WhatsApp — app desktop com gestão de contatos, mensagens com variáveis dinâmicas, agendamento e monitoramento de entrega em tempo real.

`Python` · `PyQt6` · `Automação`
https://github.com/Nishuw/Wa-Sender

### NetLog Insight
Inteligência de logs para equipamentos Cisco, FortiGate e Nokia — interpreta automaticamente interfaces, QoS, rotas e protocolos para reduzir o tempo de diagnóstico em campo.

`Python` · `Parsing` · `Redes`
https://github.com/Nishuw/NetLog-Insight

### Network Sentinel
Scanner de rede e portas com GUI dark mode — descobre dispositivos, verifica portas abertas e classifica vulnerabilidades na rede local.

`Python` · `Segurança` · `CustomTkinter`
https://github.com/Nishuw/firewall-python

### Calculadora de Sub-redes
Calculadora de sub-redes IPv4 com GUI desktop — feita para estudo de CCNA e trabalho em campo, do endereço de rede às faixas de host em um clique.

`Python` · `IPv4` · `GUI`
https://github.com/Nishuw/calculadora-subrede

---

## Open source (GitHub)

**github.com/Nishuw** — 13 repositórios públicos · 4+ anos no GitHub · 8 projetos de IA e automação · 3 seguidores

Distribuição de linguagens: Python (IA, RPA, backend) 72% · JavaScript/TypeScript 14% · HTML/CSS 9% · outros (Java, Shell, Docker) 5%.

Destaques: `DocRAG-BR` · `Projeto-Petrova` · `online-boutique-ai-agent` · `NetrouterAI` · `Wa-Sender`

---

## Versão em inglês (títulos e cargos)

**AI Engineer · Full-Stack Developer · Automation Specialist** — *Systems that read, reason and act.*

*From network cables to neural networks.* I build AI systems that read, reason and act — RAG pipelines, autonomous agents and automation that eliminates repetitive work end to end, in production. My path went from enterprise network infrastructure → backend & RPA engineering → AI engineering, which is why my systems are designed for failure modes, observability and scale from day one.

| PT-BR | EN |
|---|---|
| Analista de Sistemas RPA · Mix Fiscal · FEV 2026 — ATUAL | RPA Systems Analyst · Mix Fiscal · FEB 2026 — PRESENT |
| Analista de Desenvolvimento · Global Hitss · ABR 2025 — FEV 2026 | Development Analyst · Global Hitss · APR 2025 — FEB 2026 |
| Técnico em Automação de Redes · Global Hitss · AGO 2024 — JUL 2025 | Network Automation Technician · Global Hitss · AUG 2024 — JUL 2025 |

---

## Lacunas para preencher

Não há conteúdo no portfólio para estas seções clássicas de currículo:

- Formação acadêmica / educação
- Certificações e cursos
- Idiomas falados
- Telefone
